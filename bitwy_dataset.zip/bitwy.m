% https://www.kaggle.com/datasets/residentmario/database-of-battles?select=battles.csv
actors = readtable('battle_actors.csv');
durations = readtable('battle_durations.csv');
dyads = readtable('battle_dyads.csv');
battles = readtable('battles.csv');
commanders = readtable('commanders.csv');
terrain = readtable('terrain.csv');
weather = readtable('weather.csv');
periods = readtable('active_periods.csv');
belligerents = readtable('belligerents.csv');



%actors

actors.actor = categorical(actors.actor);

unikalne_kraje = categories(actors.actor);
wystapienia = countcats(actors.actor);

[sortowane_wystapienia, sort_index] = sort(wystapienia);

top_kraje = unikalne_kraje(sort_index(end-9:end));

figure;
barh(sortowane_wystapienia(end-9:end));
title('10 najczęściej biorących udział w bitwach państw');
ylabel('Nazwa państwa');
xlabel('Ilość bitew');
set(gca, 'YTickLabel', unikalne_kraje(sort_index(end-9:end)));
ilosci_et = sortowane_wystapienia(end-9:end);
ilosci_et = num2str(ilosci_et);
text(sortowane_wystapienia(end-9:end), (1:10), ilosci_et, 'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle');

bitwy_kraje = countcats(actors.actor);
kraje_jedna_bitwa = sum(bitwy_kraje == 1);
kraje_wiecej_bitew = sum(bitwy_kraje > 1);

colors = [0.2 0.4 0.6;
          0.7 0.3 0.2];
figure;
pie([kraje_jedna_bitwa, kraje_wiecej_bitew], {'1 bitwa', '>1 bitwa'});
colormap(colors);
title('Liczba państw biorących udział w 1 bitwie i w więcej niż 1 bitwie w stosunku do ilości wszystkich państw');
legend(sprintf('1 bitwa: %.0f', kraje_jedna_bitwa), sprintf('>1 bitwa: %.0f', kraje_wiecej_bitew), 'Location', 'bestoutside');

for i = 1:numel(top_kraje)
    atakujace = sum(actors.attacker(actors.actor == top_kraje(i)));
    obronne = sum(~actors.attacker(actors.actor == top_kraje(i)));
    
    total = atakujace + obronne;
    percentages = [atakujace, obronne] / total * 100;
    
    figure;
    pie([atakujace, obronne], {'Agresor', 'Obrońca'});
    title(['Wykres przedstawiający podział bitew ze względu na rolę dla ' top_kraje{i}]);
    legend(sprintf('Agresor: %.2f%%', percentages(1)), sprintf('Obrońca: %.2f%%', percentages(2)), 'Location', 'bestoutside');
end



%weather

weather.wx4 = categorical(weather.wx4, {'S', '$', 'F', 'W'}, {'Summer', 'Spring', 'Fall', 'Winter'});
counts = countcats(weather.wx4);

figure;
bar(counts);
title('Liczba bitew rozpoczętych w poszczególnych porach roku');
ylabel('Liczba bitew');
xlabel('Pora roku');
xticklabels(categories(weather.wx4));
for i = 1:numel(counts)
    text(i, counts(i), num2str(counts(i)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end



%dyads

attacker_counts = countcats(categorical(dyads.attacker));
[sorted_attacker_counts, attacker_sort_index] = sort(attacker_counts, 'descend');

[unique_attackers, ~, idx_attackers] = unique(dyads.attacker);
top_attackers = unique_attackers(attacker_sort_index(1:10));

defender_counts = countcats(categorical(dyads.defender));
[sorted_defender_counts, defender_sort_index] = sort(defender_counts, 'descend');

[unique_defenders, ~, idx_defenders] = unique(dyads.defender);
top_defenders = unique_defenders(defender_sort_index(1:10));

attacker_color = [0.5, 0, 0.2];
defender_color = [0, 0.5, 0];

figure;
bar(sorted_attacker_counts(1:10), 'FaceColor', attacker_color);
title('10 państw najczęściej występujących w bitwach jako atakujący');
ylabel('Liczba wystąpień w bitwach');
xlabel('Państwo');
xticklabels(top_attackers);
xtickangle(45);
for i = 1:numel(sorted_attacker_counts(1:10))
    text(i, sorted_attacker_counts(i), num2str(sorted_attacker_counts(i)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end

figure;
bar(sorted_defender_counts(1:10), 'FaceColor', defender_color);
title('10 państw najczęściej występujących w bitwach jako obrońca');
ylabel('Liczba wystąpień w bitwach');
xlabel('Państwo');
xticklabels(top_defenders);
xtickangle(45);
for i = 1:numel(sorted_defender_counts(1:10))
    text(i, sorted_defender_counts(i), num2str(sorted_defender_counts(i)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end



%commanders

[unique_commanders, ~, ic] = unique(commanders.commanders);
commander_counts = accumarray(ic, 1);
[sorted_counts, sorted_indices] = sort(commander_counts, 'descend');
top_commanders = unique_commanders(sorted_indices);
top_counts = sorted_counts;

if numel(top_commanders) > 10
    top_commanders = top_commanders(2:11);
    top_counts = top_counts(2:11);
end

figure;
bar(top_counts, 'FaceColor', [0.2 0.4 0.9]);
title('Dowódcy najwększej liczby bitew');
ylabel('Liczba bitew');
xlabel('Dowódca');
xticks(1:numel(top_commanders));
xticklabels(top_commanders);



%periods

duration_data = periods.duration_max/1440;

duration_data_filtered = duration_data(duration_data <= 5);

figure;
violin(duration_data_filtered, 'FaceColor', [0.7 0.7 0.7]);
xlabel('Bitwy');
ylabel('Długość trwania (dni)');
title('Wykres skrzypcowy długości trwania bitew (do 5 dni)');

duration_data_above_5_days = duration_data(duration_data > 5);
figure;
histogram(duration_data_above_5_days, 'BinWidth', 1, 'FaceColor', [0.45 0.9 0.7]);
xlabel('Długość trwania (dni)');
ylabel('Liczba bitew');
title('Histogram długości trwania bitew powyżej 5 dni');


periods_years = year(periods.start_time_min);
periods_centuries = ceil(periods_years / 100);

battle_counts = zeros(4,1);
for i = 1:numel(periods_centuries)
    if periods_centuries(i) >= 17 && periods_centuries(i) <= 20
        battle_counts(periods_centuries(i) - 16) = battle_counts(periods_centuries(i) - 16) + 1;
    end
end

figure;
bar(17:20, battle_counts);
title('Ilość bitew w poszczególnych wiekach');
ylabel('Ilość bitew');
xlabel('Wiek');



%battles

idx_ww2 = contains(battles.war, 'WORLD WAR II', 'IgnoreCase', true);
battles.war(idx_ww2) = {'WORLD WAR II'};
idx_ww1 = contains(battles.war, 'WORLD WAR I', 'IgnoreCase', true);
idx_ww1 = idx_ww1 & ~idx_ww2;
battles.war(idx_ww1) = {'WORLD WAR I'};
unikalne_wojny = unique(battles.war);
liczba_bitew_na_wojne = countcats(categorical(battles.war));
[sorted_bitwy, idx] = sort(liczba_bitew_na_wojne, 'descend');
top_wojny = unikalne_wojny(idx(1:10));

figure;
bar(sorted_bitwy(1:10), 'FaceColor', [0.9 0.35 0.9]);
xlabel('Wojna');
ylabel('Liczba bitew');
title('10 wojen, w których wystąpiło najwięcej bitew');
xticks(1:10);
xticklabels(top_wojny);
xtickangle(45);

for i = 1:numel(sorted_bitwy(1:10))
    text(i, sorted_bitwy(i), num2str(sorted_bitwy(i)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end


unikalne_lokalizacje = unique(battles.locn);
liczba_wystapien_lokalizacji = countcats(categorical(battles.locn));
[sorted_wystapienia, idx] = sort(liczba_wystapien_lokalizacji, 'descend');
top_lokalizacje = unikalne_lokalizacje(idx(1:10));

figure;
bar(sorted_wystapienia(1:10), 'FaceColor', [1 0.5 0]);
xlabel('Państwo / region');
ylabel('Liczba bitew');
title('10 państw / regionów z największą ilością bitew');
xticks(1:10);
xticklabels(top_lokalizacje);
xtickangle(45);

for i = 1:numel(sorted_wystapienia(1:10))
    text(i, sorted_wystapienia(i), num2str(sorted_wystapienia(i)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end


bitwy_attacker = sum(battles.aeroa == 1);
bitwy_defender = sum(battles.aeroa == -1);
bitwy_neutral = sum(battles.aeroa == 0);

figure;
bar([bitwy_attacker; bitwy_defender; bitwy_neutral]);
xlabel('Strona z przewagą powietrzną');
ylabel('Liczba bitew');
title('Liczba bitew w zależności od przewagi powietrznej danej strony');
xticklabels({'Attacker', 'Defender', 'Neither'});
text(1, bitwy_attacker, num2str(bitwy_attacker), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
text(2, bitwy_defender, num2str(bitwy_defender), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
text(3, bitwy_neutral, num2str(bitwy_neutral), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');


bitwy_minor = sum(battles.surpa == 1);
bitwy_substantial = sum(battles.surpa == 2);
bitwy_complete = sum(battles.surpa == 3);
bitwy_neutral = sum(battles.surpa == 0);
bitwy_defender = sum(battles.surpa == -1) + sum(battles.surpa == -2) + sum(battles.surpa == -3);

figure;
bar([bitwy_neutral, bitwy_minor, bitwy_substantial, bitwy_complete, bitwy_defender], 'FaceColor', [0.5 0 0.5]);
xlabel('Zaskoczenie');
ylabel('Liczba bitew');
title('Liczba bitew w zależności od stopnia zaskoczenia agresora albo obrońcy');
xticklabels({'Neither side or didnt matter', 'Minor surprise achieved by attacker', 'Substantial surprise achieved by attacker', 'Complete surprise achieved by attacker', 'Surprise achieved by defender'});

text(1, bitwy_neutral, num2str(bitwy_neutral), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
text(2, bitwy_minor, num2str(bitwy_minor), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
text(3, bitwy_substantial, num2str(bitwy_substantial), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
text(4, bitwy_complete, num2str(bitwy_complete), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
text(5, bitwy_defender, num2str(bitwy_defender), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');


%belligerents

figure;
histogram(belligerents.str, 'FaceColor', [0.9 0.5 0.5]);
xlabel('Liczebność armii');
ylabel('Liczba armii o określonej liczebności');
title('Histogram liczebności armii');

[sorted_str, idx] = sort(belligerents.str, 'descend');
top_nazwy_armii = belligerents.nam(idx(3:12));

figure;
bar(sorted_str(3:12), 'FaceColor', [0.9 0 0.5]);
xlabel('Armia');
ylabel('Liczebność wojska');
title('10 największych armii biorących udział w bitwie');
xticks(1:10);
xticklabels(top_nazwy_armii);
xtickangle(45);
for i = 1:numel(sorted_str(3:12))
    text(i, sorted_str(i+2), num2str(sorted_str(i+2)/1000000), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end


army_counts = countcats(categorical(belligerents.nam));

[sorted_counts, sorted_index] = sort(army_counts, 'descend');

top_armies = belligerents.nam(sorted_index(1:10));
top_counts = sorted_counts(1:10);

figure;
bar(top_counts);
title('10 armii, które wzięło udział w największej liczbie bitew');
ylabel('Liczba bitew');
xlabel('Nazwa armii');
xticks(1:10);
xticklabels(top_armies);
xtickangle(45);

for i = 1:numel(top_counts)
    text(i, top_counts(i), num2str(top_counts(i)), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
end


